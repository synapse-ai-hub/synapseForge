<p align="center">
  <img src="https://github.com/synapse-ai-hub/sources/raw/main/logo.png" alt="Logo" width="150">
</p>

---

<h1 align="center">Herramientas Externas (Tools) — Guía de Creación</h1>

---

<p align="center">
  <a href="./LICENSE">
    <img src="https://img.shields.io/badge/license-Apache%202.0-blue.svg" alt="License: Apache 2.0" />
  </a>
</p>

---

<h3 align="center">Estándar para desarrollar herramientas externas del agente synapseForge</h3>

---

## Descripción

Esta guía define el estándar para crear **herramientas externas (tools)** que el agente synapseForge puede descubrir, cargar y ejecutar. Las tools se almacenan como archivos `.py` individuales en `~/.config/synapseForge/tools/` y son cargadas dinámicamente por la clase `Tools` del backend.

Cada tool es un archivo Python autocontenido que expone una función `async` como punto de entrada. El sistema de registro lee el docstring del módulo y la firma de la función para generar automáticamente un schema compatible con function-calling del LLM.

### ✨ Características

- **Auto-descubrimiento**: cada `.py` en la carpeta tools se carga automáticamente como una tool independiente
- **Schema automático**: el docstring y type hints generan el schema function-calling sin configuración adicional
- **Aislamiento**: cada tool es autocontenida, con sus propias dependencias y variables de entorno
- **Modo dual**: funciona tanto como tool del agente como script CLI independiente
- **Tolerancia a fallos**: si una tool falla al cargarse, no impide la carga del resto

---

## ¿Qué resuelve?

- **Duplicación de código**: todas las tools siguen el mismo patrón, facilitando el mantenimiento
- **LLM no entiende la tool**: un docstring mal escrito confunde al modelo; este estándar garantiza descripciones claras
- **Errores en tiempo de ejecución**: la coerción defensiva y el manejo de errores evitan crashes
- **Dependencias ocultas**: el archivo `.env` propio permite que la tool funcione standalone sin depender del proyecto

---

## Estructura de una Tool

```plaintext
~/.config/synapseForge/tools/
│
├── nombre_tool.py           # Código de la tool (un archivo = una tool)
│
├── lib/                     # (Opcional) dependencias compartidas entre tools
│   ├── .env                 # Variables de entorno para modo standalone
│   └── data/                # Archivos de datos estáticos (CSV, JSON, etc.)
│
└── ...otras_tool.py         # Más tools, cada una en su propio archivo
```

Cada archivo `.py` **directamente** en `tools/` (no en subdirectorios) es una tool.

---

## Estructura del Archivo

```python
"""Descripción corta de la tool — esto es lo que ve el LLM como tool description.

Párrafos adicionales con más detalle del comportamiento.
"""

import argparse
import asyncio
import os
import sys

from dotenv import load_dotenv

# ── Entorno ─────────────────────────────────────────────────────
_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
_ENV_PATH = os.path.join(_TOOLS_DIR, "lib", ".env")
load_dotenv(dotenv_path=_ENV_PATH)


# ── Handler principal ──────────────────────────────────────────


async def mi_tool(param1: str, param2: int | None = None) -> str:
    """Descripción de la función — el LLM la usa para entender el comportamiento.

    Explicación más detallada de qué hace la tool y cómo se comporta
    según los argumentos.

    Args:
        param1: Descripción del primer parámetro.  Explicar qué pasa
            si se omite, si tiene valores especiales, etc.
        param2: Descripción del segundo parámetro.  Si es opcional
            (``None``), explicar cuál es el comportamiento default.

    Returns:
        Descripción del string que devuelve.
    """
    # ── Coerción defensiva ──
    if not isinstance(param2, int):
        param2 = int(param2)

    # ── Lógica de la tool ──
    try:
        # ...
        return "Resultado de la tool"
    except Exception as e:
        return f"Error en mi_tool: {e}"


# ── Punto de entrada standalone ────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="...")
    parser.add_argument("param1", type=str, help="...")
    parser.add_argument("--param2", type=int, default=None, help="...")
    args = parser.parse_args()

    resultado = asyncio.run(mi_tool(param1=args.param1, param2=args.param2))
    print(resultado)
```

---

## Reglas por Sección

### 1. Módulo Docstring (Tool Description)

La **primera línea** del docstring del módulo es la descripción que el LLM ve para decidir si usa la tool.

```python
"""Descripción corta de la tool — esto es lo que ve el LLM como tool description.

Párrafos adicionales con más detalle del comportamiento.
"""
```

**Reglas:**
- Máximo **80 caracteres** en la primera línea
- La primera línea debe describir QUÉ hace la tool (no cómo)
- Párrafos adicionales pueden detallar comportamiento

### 2. Handler Function

La función principal **debe**:

| Elemento | Obligatorio | Detalle |
|----------|-------------|---------|
| `async def` | ✅ Sí | El ejecutor de tools hace `await` sobre el handler |
| Type hints | ✅ Sí | Todos los parámetros deben tener tipo |
| `-> str` | ✅ Sí | El handler devuelve texto que el LLM interpreta |
| Google-style docstring | ✅ Sí | El parser extrae descripciones de `Args:` |

**Firma correcta:**
```python
async def mi_tool(param1: str, param2: int) -> str:
async def mi_tool(param: str | None = None) -> str:
```

**Firma incorrecta:**
```python
# ❌ No async — causa "object str can't be used in 'await' expression"
def mi_tool(param: str) -> str:
# ❌ Sin type hints — el schema no puede determinar el tipo
async def mi_tool(param):
# ❌ No devuelve string — el LLM espera texto
async def mi_tool(param: str) -> dict:
```

### 3. Args: en el Docstring

El LLM lee estas descripciones para saber qué pasarle a la tool. Cada parámetro debe explicar:

- **Qué es** el parámetro
- **Qué pasa si se omite** (si es opcional)
- **Valores típicos o ejemplos**

```python
    Args:
        param1: Descripción del parámetro.  Si es opcional (``None``),
            explicar cuál es el comportamiento default.
```

**⚠️ Importante:** la descripción debe estar en **una sola línea** (el parser solo toma la primera línea del `param:`). Si necesitás más de una línea, el parser actual no la captura — usá una línea larga.

### 4. Coerción Defensiva

Los LLMs a veces mandan tipos incorrectos (strings en vez de enteros, etc.). Siempre validar:

```python
async def mi_tool(param: int = 0) -> str:
    # Coerción defensiva
    if not isinstance(param, int):
        param = int(param)
```

### 5. async / to_thread

El handler **debe ser async**. Las operaciones bloqueantes (conexiones DB, llamadas HTTP, etc.) deben ejecutarse en un thread aparte para no bloquear el event loop:

```python
import asyncio

async def mi_tool(url: str) -> str:
    # Llamada bloqueante → thread aparte
    respuesta = await asyncio.to_thread(_hacer_request_sincronico, url)

    try:
        resultado = await asyncio.to_thread(_procesar_respuesta, respuesta)
        return resultado
    finally:
        await asyncio.to_thread(_liberar_recursos)
```

### 6. try/except General

Toda la lógica de la tool debe estar dentro de un `try/except` que devuelva el error como string. **Nunca** dejar que la tool lance una excepción sin capturar:

```python
try:
    # ... toda la lógica ...
    return resultado
except Exception as e:
    return f"Error en la tool: {e}"
```

### 7. Modo Standalone (CLI)

Toda tool debe poder ejecutarse como script independiente para pruebas:

```python
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="...")
    parser.add_argument("param1", type=str, help="...")
    args = parser.parse_args()

    resultado = asyncio.run(mi_tool(param1=args.param1))
    print(resultado)
```

Siempre usar `asyncio.run()` porque el handler es `async def`.

### 8. .env para Modo Standalone

Si la tool necesita credenciales (DB, API keys, etc.), crear un `lib/.env` con las variables necesarias:

```bash
# lib/.env — cargado por load_dotenv en la tool
API_KEY=tu_api_key
API_URL=https://api.ejemplo.com
```

La tool carga este `.env` al inicio:

```python
_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
_ENV_PATH = os.path.join(_TOOLS_DIR, "lib", ".env")
load_dotenv(dotenv_path=_ENV_PATH)
```

---

## Flujo de Carga

```mermaid
sequenceDiagram
    participant Tools as Tools.__init__
    participant Scanner as _scan_external_tools
    participant Registry as _build_tools_registry
    participant LLM as LLM (agente)
    participant Executor as _execute_tool

    Tools->>Scanner: Escanea ~/.config/synapseForge/tools/*.py
    loop Cada archivo .py
        Scanner->>Scanner: Importa módulo via importlib
        alt Carga exitosa
            Scanner->>Scanner: Lee módulo docstring (tool description)
            Scanner->>Scanner: Busca función async (handler)
            Scanner->>Scanner: Agrega a _external_tools
        else Error
            Scanner->>Scanner: Loguea warning, continúa
        end
    end
    Scanner-->>Tools: Lista de {name, description, fn}

    Tools->>Registry: Construye schema function-calling
    Registry->>Registry: inspect.signature(handler) → parámetros + tipos
    Registry->>Registry: _parse_param_descriptions(doc) → descripciones
    Registry-->>Tools: Lista de schemas OpenAI-compatible

    Tools-->>LLM: tools_registry → schemas

    LLM->>LLM: Decide qué tool usar
    LLM->>Executor: tool_name + kwargs
    Executor->>Executor: await handler(**kwargs)
    Executor-->>LLM: resultado como string
```

---

## Mecanismo de Carga (Backend)

El archivo `backend/agent/tools.py` es el orquestador. Los puntos clave:

```python
# _scan_external_tools — carga cada .py en su propio try/except
for module_file in py_files:
    try:
        # ... importlib ...
        spec.loader.exec_module(mod)
        # Busca función async con nombre igual al archivo
        handler = getattr(mod, module_name, None)
        if handler is None or not callable(handler):
            continue
        results.append({
            "name": module_name,
            "description": (mod.__doc__ or "").strip().split("\n")[0],
            "fn": handler,
        })
    except Exception as e:
        logger.warning("Failed to load external tool '%s': %s", module_name, e)
        continue  # Sigue con la siguiente tool

# _execute_tool — dispatch a external tools (priority)
for ext in self._external_tools:
    if ext["name"] == tool_name:
        handler = ext["fn"]
        return await handler(**kwargs)  # ← por eso async es obligatorio
```

---

## Stack Tecnológico

![Python](https://img.shields.io/badge/Python-3.12+-3776ab?logo=python&logoColor=white)
![dotenv](https://img.shields.io/badge/python--dotenv-1.x-ECD53F?logo=python&logoColor=white)

---

## Referencias

| Documento | Contenido |
|---|---|
| `backend/agent/tools.py` | Clase Tools: carga, registro y ejecución de tools |

---

## Licencia

Este proyecto está licenciado bajo los términos especificados en el archivo [LICENSE](../../LICENSE) ubicado en la raíz del repositorio.

---

Copyright (c) 2026 SYNASPE AI SAS

---
