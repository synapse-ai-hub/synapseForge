<p align="center">
  <img src="https://github.com/synapse-ai-hub/sources/raw/main/logo.png" alt="Logo" width="150">
</p>

---

<h1 align="center">Agentes — Guía de Creación</h1>

---

<p align="center">
  <a href="./LICENSE">
    <img src="https://img.shields.io/badge/license-Apache%202.0-blue.svg" alt="License: Apache 2.0" />
  </a>
</p>

---

<h3 align="center">Estándar para definir sub-agentes del ecosistema synapseAgent</h3>

---

## Descripción

Esta guía define el estándar para crear **agentes** que el sistema synapseAgent puede descubrir, cargar y ejecutar como sub-agentes. Los agentes se definen como archivos Markdown individuales en `~/.config/synapseAgent/agents/` y son leídos en tiempo de ejecución por el módulo de permisos.

Cada agente combina tres cosas:

- **Frontmatter YAML**: metadatos (nombre, descripción, permisos, parámetros del modelo).
- **Cuerpo Markdown**: instrucción de sistema (system prompt) que define la personalidad y el comportamiento del agente.
- **Resolución dinámica**: el sistema lee el archivo al ejecutar el agente, extrae permisos y parámetros, y filtra tools/skills según lo declarado.

---

## Estructura de archivos

```
~/.config/synapseAgent/
├── agents/
│   ├── mi-agente.md           # Definición de un agente
│   └── otro-agente.md         # Otro agente
├── tools/                     # Herramientas externas (ver guía de tools)
├── skills/                    # Skills (subdirectorios con SKILL.md)
└── config.json                # Configuración general
```

Cada archivo `.md` directamente en `agents/` es un agente. El nombre del archivo (sin `.md`) es el identificador que se usa para invocarlo desde la tool `task`.

---

## Formato del archivo

El archivo tiene dos secciones separadas por `---`:

```yaml
---
# YAML frontmatter: metadatos, permisos y parámetros
---

# Cuerpo: system prompt del agente
# Aquí va la instrucción de sistema que define
# personalidad, reglas de negocio, formato de respuesta, etc.
```

### Frontmatter

| Campo | Tipo | Obligatorio | Descripción |
|-------|------|-------------|-------------|
| `name` | `str` | No | Nombre visible del agente. Si se omite, usa el nombre del archivo sin `.md`. Debe ser el nombre exacto del archivo, sin la extensión `.md`.|
| `description` | `str` | No | Descripción breve. Se usa en el listado de agentes. |
| `parameters` | `dict` | No | Parámetros del modelo (ver sección correspondiente). |
| `permission` | `dict` | No | Permisos de tools y skills (ver sección de permisos). |

### Cuerpo (system prompt)

Todo el texto que está debajo del segundo `---` se usa como instrucción de sistema del agente. Ahí se define:

- Rol y personalidad
- Reglas de negocio
- Formato de respuesta esperado
- Instrucciones sobre cómo usar las tools disponibles
- Contexto específico del dominio

No hay límite de extensión. El contenido se inyecta literalmente en el mensaje `system` del LLM.

---

## Parámetros del modelo (`parameters`)

El bloque `parameters` en el frontmatter define los hiperparámetros del modelo que se usan al ejecutar el agente.

### Campos soportados

| Campo | Tipo | Default | Descripción |
|-------|------|---------|-------------|
| `temperature` | `float` | `0.0` | Controla la creatividad (0.0 = determinista, 1.0 = más creativo). |
| `top_p` | `float` | `0.5` | Nucleus sampling. Filtra tokens menos probables. |
| `model` | `str` o `null` | `null` | Override del modelo. Si es `null`, usa el modelo que ya tiene resuelto el agente padre. |
| `max_tokens` | `int` | `3000` | Máximo de tokens a generar. |
| `seed` | `int` | — | Semilla para generación determinista. Compatible con Ollama y Groq. |

### Cómo se resuelven

El sistema aplica esta lógica:

1. Toma los valores por defecto: `{"temperature": 0.0, "top_p": 0.5, "model": null}`
2. Los combina con lo que declare el frontmatter (lo del frontmatter pisar los defaults)
3. **Todos** los campos del frontmatter se preservan en el dict resultante, incluso los que no están en la lista de defaults. Esto permite que en el futuro se agreguen nuevos parámetros sin cambiar el código de resolución.

### Comportamiento por proveedor

| Parámetro | Groq (API) | Ollama (local) |
|-----------|------------|----------------|
| `temperature` | Sí | Sí |
| `top_p` | Sí | Sí |
| `max_tokens` | Sí (`max_tokens`) | Sí (`num_predict`) |
| `seed` | Sí | Sí |
| Otros (`num_ctx`, `top_k`, etc.) | No | Sí (se pasan a `options`) |

---

## Permisos (`permission`)

El bloque `permission` controla qué tools y skills puede usar el agente.

### Estructura

```yaml
permission:
  # Permisos de tools: clave = nombre de la tool, valor = "allow" o "deny"
  nombre_tool: allow
  otra_tool: deny

  # Permisos de skills: sub-bloque "skill"
  skill:
    nombre_skill: allow
    otra_skill: deny
```

### Cómo funciona para tools

1. El sistema extrae del frontmatter todas las claves del bloque `permission` cuyo valor **no sea un dict**. Las claves con valor dict (como `skill`) se ignoran en la resolución de tools.
2. Convierte esas claves en reglas: `{"permission": "<nombre>", "pattern": "*", "action": "<valor>"}`.
3. Para cada tool registrada, evalúa si su nombre coincide con alguna regla.
4. Solo las tools que evalúan a `"allow"` se incluyen en el registro que ve el LLM.

**Casos:**

| Situación | Resultado |
|-----------|-----------|
| `permission` no declarado | Todas las tools disponibles |
| `permission: {}` | Todas las tools disponibles |
| `query: allow` | Solo `query` disponible |
| `query: allow`, `websearch: deny` | `query` disponible, `websearch` no |
| `"*": allow`, `websearch: deny` | Todas excepto `websearch` |
| Tool no listada en permisos | `"ask"` → excluida |

### Cómo funciona para skills

1. El sistema extrae el sub-bloque `permission.skill`.
2. Si no existe el sub-bloque, todas las skills están disponibles.
3. Si existe, filtra las skills de la misma forma que las tools: solo pasan las que evalúan a `"allow"`.

**Casos:**

| Situación | Resultado |
|-----------|-----------|
| `skill:` no declarado | Todas las skills disponibles |
| `skill: {}` | Todas las skills disponibles |
| `skill: {analisis: allow}` | Solo `analisis` disponible |
| `"*": deny` bajo `skill` | Ninguna skill disponible |
| Skill no listada | `"ask"` → excluida |

### Uso de wildcards

El sistema soporta el wildcard `*` en los nombres de permisos:

```yaml
permission:
  "*": allow           # Todas las tools permitidas
  websearch: deny      # Excepto websearch

  skill:
    "*": deny          # Ninguna skill permitida
    analisis: allow    # Excepto analisis
```

El `*` matchea cualquier secuencia (incluyendo vacío).

### Valores de acción

| Valor | Efecto |
|-------|--------|
| `allow` | Tool/skill incluida |
| `deny` | Tool/skill excluida |
| `ask` (implícito) | Tool/skill excluida |
| cualquier otro | Excluida |

Solo `"allow"` permite el acceso. Cualquier otro valor (incluyendo no estar listado) equivale a exclusión.

---

## Flujo de invocación

Cuando el agente principal (router) o un sub-agente invoca a un agente mediante la tool `task`:

```mermaid
sequenceDiagram
    participant Parent as Agente padre
    participant Task as tool task()
    participant Perm as permissions.py
    participant Runner as Runner (event loop)
    participant LLM as LLM

    Parent->>Task: task(agent_name, prompt)
    Task->>Perm: get_agent_prompt(agent_name)
    Perm-->>Task: system_prompt (cuerpo del markdown)
    Task->>Perm: get_tool_permissions(agent_name)
    Perm-->>Task: tool_permissions dict
    Task->>Perm: get_skill_permissions(agent_name)
    Perm-->>Task: skill_permissions dict
    Task->>Perm: get_agent_parameters(agent_name)
    Perm-->>Task: parameters dict
    Task->>Runner: ejecutar(system_prompt, tool_permissions, skill_permissions, parameters)
    Runner->>Perm: filter_tools(tools_registry, tool_permissions)
    Perm-->>Runner: tools filtradas
    Runner->>Runner: format_skills_section(skill_permissions)
    Runner->>LLM: chat(system_prompt + tools + skills)
    LLM-->>Runner: respuesta / tool_calls
    Runner-->>Task: resultado final
    Task-->>Parent: <task><task_result>...xml...
```

---

## Aspectos técnicos

### Ubicación

Los agentes deben colocarse en:

- **Linux/macOS**: `~/.config/synapseAgent/agents/`
- **Windows**: `%USERPROFILE%\.config\synapseAgent\agents\`

El sistema crea automáticamente el directorio al iniciar si no existe.

### Formato de archivo

- Extensión: `.md` (Markdown)
- Codificación: UTF-8 (con o sin BOM)
- Frontmatter: YAML entre `---` y `---`
- Separación: el primer `---` abre el frontmatter, el segundo lo cierra. Todo lo que sigue es el cuerpo.

### Resolución del nombre del agente

El identificador del agente es el nombre del archivo sin la extensión `.md`. Cuando se invoca desde la tool `task`, se usa este identificador:

```
agent_name = "mi-agente"  # → busca agents/mi-agente.md
```

### Manejo de errores

- Si el archivo no existe o no tiene frontmatter válido, la tool `task` devuelve un error.
- Si el frontmatter tiene YAML inválido, se parsea como `{}` y se usa todo por defecto.
- Si `permission` no está declarado, se permite todo (tools y skills).
- Si `parameters` no está declarado, se usan los valores por defecto del sistema.

---

## Referencia rápida

### Estructura mínima de un agente

```yaml
---
name: mi-agente
description: Hace algo específico.
---

Eres un asistente que se dedica a hacer algo específico.
Usa las tools disponibles para resolver la tarea.
Responde siempre en español.
```

### Estructura completa

```yaml
---
name: mi-agente
description: Descripción del agente.

parameters:
  temperature: 0.3
  top_p: 0.7
  model: null
  max_tokens: 4000
  seed: 2603

permission:
  query: allow
  explore_db: allow
  websearch: deny
  skill:
    analisis: allow
    websearch: deny
---

Eres un asistente especializado.
Instrucciones detalladas aquí.
```

### Archivos del sistema que procesan el agente

| Archivo | Función |
|---------|---------|
| `backend/agent/permissions.py` | Resuelve frontmatter: `get_agent_prompt()`, `get_tool_permissions()`, `get_skill_permissions()`, `get_agent_parameters()` |
| `backend/agent/permissions.py` | Filtrado: `filter_tools()`, `filter_skills()` |
| `backend/agent/loop.py` | Orquesta la ejecución del agente |
| `backend/agent/tools.py` | Tool `task()` que invoca sub-agentes |
| `backend/agent/utils/skill_loader.py` | `format_skills_section()` — carga skills y aplica filtros |

---

## Licencia

Este proyecto está licenciado bajo los términos especificados en el archivo [LICENSE](../../LICENSE) ubicado en la raíz del repositorio.

---

Copyright (c) 2026 SYNASPE AI SAS

---
